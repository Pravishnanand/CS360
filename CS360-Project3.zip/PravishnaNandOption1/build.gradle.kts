// Top-level build file where you can add configuration options common to all sub-projects/modules.

buildscript {
    repositories {
        google()
        jcenter()
        // Add other repositories if needed.
    }
    dependencies {
        classpath("com.android.tools.build:gradle:8.1.4")
        // Add other dependencies if needed for the build script.
    }
}

// Include settings for sub-projects/modules if applicable.

allprojects {
    repositories {
        google()
        jcenter()
        // Add other repositories if needed.
    }
}