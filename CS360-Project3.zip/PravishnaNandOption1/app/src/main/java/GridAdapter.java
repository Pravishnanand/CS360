import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pravishnanandoption1.R;

import java.util.List;

public class GridAdapter extends RecyclerView.Adapter<GridAdapter.ViewHolder> {

    private final List<GridItemModel> data;
    private final OnItemClickListener itemClickListener;

    public interface OnItemClickListener {
        void onDeleteClick(int position);

        void onEditClick(int position);
    }

    public GridAdapter(List<GridItemModel> data, OnItemClickListener itemClickListener) {
        this.data = data;
        this.itemClickListener = itemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.grid_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        GridItemModel item = data.get(position);

        holder.textViewLabel.setText(item.getLabel());
        holder.textViewValue.setText(item.getValue());

        holder.buttonDelete.setOnClickListener(v -> itemClickListener.onDeleteClick(position));
        holder.buttonEdit.setOnClickListener(v -> itemClickListener.onEditClick(position));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewLabel;
        public TextView textViewValue;
        public Button buttonDelete;
        public Button buttonEdit;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewLabel = itemView.findViewById(R.id.textViewLabel);
            textViewValue = itemView.findViewById(R.id.textViewValue);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
        }
    }
}
