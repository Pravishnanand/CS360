package com.example.pravishnanandoption1;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class GridActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid); // Make sure you have an XML layout file named "activity_grid.xml"

        // Initialize RecyclerView and its adapter
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        GridAdapter adapter = new GridAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Initialize your data list
        List<GridItemModel> dataList = new ArrayList<>();

        // Add sample data (you can replace this with your actual data)
        dataList.add(new GridItemModel());
        dataList.add(new GridItemModel());
        dataList.add(new GridItemModel());

        // Set the data to the adapter
        adapter.setData();
    }
}