package com.example.pravishnanandoption1.data;

import java.io.IOException;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    private final UserDatabase userDatabase;

    public LoginDataSource(UserDatabase userDatabase) {
        this.userDatabase = userDatabase;
    }

    public Result.Error login(String username) {
        try {
            // Check if a user with the given username exists in the database
            User user = userDatabase.getUserByUsername();
            if (user != null) {
                user.getPassword();
            }// If authentication fails, return an error result
            return new Result.Error(new IOException("Invalid credentials"));
        } catch (Exception e) {
            // Handle exceptions and return an error result
            return new Result.Error(new IOException("Error logging in", e));
        }
    }
}