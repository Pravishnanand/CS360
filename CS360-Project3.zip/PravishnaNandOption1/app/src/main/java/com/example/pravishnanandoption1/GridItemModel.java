package com.example.pravishnanandoption1;

public class GridItemModel {
    public GridItemModel() {
    }
}
