package com.example.pravishnanandoption1;

import android.app.Activity;

public class LoginActivity extends Activity {
}
