package com.example.pravishnanandoption1.data;

public class User {
    public void getPassword() {
    }

    public String getId() {
        return null;
    }

}
