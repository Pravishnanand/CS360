package com.example.pravishnanandoption1.data;

public class UserDatabase {
    public User getUserByUsername() {
        return null;
    }
}
